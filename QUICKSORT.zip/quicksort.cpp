#include <iostream>
using namespace std;
#include "quicksort.h"



void datos(){

int A[10]= {123, -6, 13, -33, -98, 333, 23, -5, 0, -100};
    cout<<"Elementos originales"<<endl;
    for(int i=0;i<10;i++)
        {
            cout<<"["<<A[i]<<"]";
        }
    cout<<"\nElementos ordenados"<<endl;
    ordenar(A,0,9);
    for(int i=0;i<10;i++)
        {
            cout<<"["<<A[i]<<"]";
        }


}


int mitad (int a[],int pinicial, int pfinal)
{
    return a[(pinicial+pfinal)/2];
}


void ordenar (int a[],int pinicial, int pfinal)
{

    int i=pinicial;
    int j=pfinal;
    int temp;
    int piv=mitad(a,pinicial,pfinal);

    do
    {
        while(a[i]<piv)
        {
            i++;
        }
        while(a[j]>piv)
        {
            j--;
        }
        if(i<=j)
        {
            temp =a[i];
            a[i]=a[j];
            a[j]=temp;
            i++;
            j--;
        }
    }
    while(i<=j);
    if(pinicial<j)
    {
        ordenar(a,pinicial,j);
    }
    if(i<pfinal)
    {
      ordenar(a,i,pfinal);
    }
}
