int mitad (int a[],int pinicial, int pfinal);
void ordenar (int a[],int pinicial, int pfinal);
void datos ();