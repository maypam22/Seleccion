#include <iostream>
using namespace std;
#include "quicksort.h"


int main()
{
    datos();
    return 0;

}


